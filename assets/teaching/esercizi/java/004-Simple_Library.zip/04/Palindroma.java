import java.util.Scanner;

public class Palindroma {
	
	 public static void main(String args[])
	   {
	      String immessa, invertita="";
	      Scanner in = new Scanner(System.in);
	 
	      System.out.println("Inserisci la stringa per verificare se sia palidroma");
	      immessa = in.nextLine();
	 
	      int lunghezza = immessa.length();
	 
	      for ( int i = lunghezza-1 ; i >= 0 ; i-- )
	    	  invertita = invertita + immessa.charAt(i); //copio in 'invertita' la stringa 'immessa' al contrario
	 
	      if (immessa.equals(invertita))
	         System.out.println("La stringa � palindroma");
	      else
	         System.out.println("La stringa non � palindroma");
	 
	   }

}
