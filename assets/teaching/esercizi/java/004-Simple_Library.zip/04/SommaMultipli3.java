public class SommaMultipli3 {
	
	public static void main(String[] args){
	
	int somma = 0;
	int[] arrayInteri = new int[12];
	
	for (int i = 0 ; i < 12 ; i++) //inizializzazione al valore dell'indice
		arrayInteri[i] = i;
	for (int i = 0 ; i < 12 ; i++)
		if ( i%3 == 0 ) //ricorda che il modulo � il resto della divisione: 0%3=0, 1%3=1, 2%3=2, 3%3=0, 4%3 =1, etc
			somma += arrayInteri[i];
	System.out.println("" + somma);
	}
}
