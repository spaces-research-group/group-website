public class MiglioriStudenti {

	public static String[] selezionaStudentiMigliori(String[] studenti, int[] voti){

		int num_migliori = 0;

		for(int i=0; i<studenti.length; i++){
			if(voti[i] == 30)
				num_migliori++;
		}
		
		String [] migliori = new String[num_migliori];
		int count = 0;

		for(int i=0; i<studenti.length; i++){
			if(voti[i] == 30){
				migliori[count] = studenti[i];
				count++;
			}
		}
		
		return migliori;
				
	}
		
	public static void main(String[] args) {
		int num_stud = 5;
		String[] studenti = new String[num_stud];
		int[] voti = new int[num_stud];
		studenti[0] = "mario";
		studenti[1] = "vincenzo";
		studenti[2] = "dario";
		studenti[3] = "matteo";
		studenti[4] = "silvio";

		voti[0] = 18;
		voti[1] = 30;
		voti[2] = 30;
		voti[3] = 20;
		voti[4] = 30;

		String[] studMigliori = selezionaStudentiMigliori(studenti, voti);
		
		for ( int i = 0 ; i < studMigliori.length; i++ )
			System.out.println("Studente: " + studMigliori[i]);
	}
}