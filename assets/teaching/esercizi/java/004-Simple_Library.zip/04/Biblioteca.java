import java.util.Scanner;

public class Biblioteca {
	public static void main(String args[]) {
		// Definisco l'elenco dei titoli nella base di dati
		String[] libri = new String[10];
		libri[0] = "Le Avventure di Tom Sawyer";
		libri[1] = "Il Buio Oltre la Siepe";
		libri[2] = "La Gerusalemme Liberata";
		libri[3] = "La Divina Commedia";
		libri[4] = "2000 Leghe Sotto i Mari";
		libri[5] = "Il Socio";
		libri[6] = "Le Cronache di Narnia";
		
		Scanner in = new Scanner(System.in);
		System.out.print("Immettere il titolo di un libro: ");
		String richiesta = in.nextLine();
		
		boolean trovato = false;
		for (int i = 0; i < libri.length; i++)
			if (richiesta.equals(libri[i])) {
				System.out.println("Trovato! In posizione: " + i);	
				trovato = true;
			}
		if (!trovato) // if (!trovato) equivale a scrivere if(trovato == false)
			System.out.println("Libro non trovato");
	}
}