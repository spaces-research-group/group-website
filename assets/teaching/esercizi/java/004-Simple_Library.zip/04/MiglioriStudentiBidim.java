public class MiglioriStudentiBidim {

	public static String[] selezionaStudentiMigliori(String[] studenti, int[][] voti){

		int num_migliori = 0;

		for(int i=0; i<studenti.length; i++){
			if(voti[i][0] > 25 && voti[i][1] > 25)
				num_migliori++;
		}
		
		String [] migliori = new String[num_migliori];
		int count = 0;

		for(int i=0; i<studenti.length; i++){
			if(voti[i][0] > 25 && voti[i][1] > 25 ){
				migliori[count] = studenti[i];
				count++;
			}
		}
		
		return migliori;
				
	}
		
	public static void main(String[] args) {
		int num_stud = 5;
		String[] studenti = new String[num_stud];
		int[][] voti = new int[num_stud][2];
		studenti[0] = "mario";
		studenti[1] = "vincenzo";
		studenti[2] = "dario";
		studenti[3] = "matteo";
		studenti[4] = "silvio";

		//voto dello scritto di ciascun alunno
		voti[0][0] = 18;
		voti[1][0] = 30;
		voti[2][0] = 30;
		voti[3][0] = 20;
		voti[4][0] = 30;

		//voto orale ciascun alunno
		voti[0][1] = 30;
		voti[1][1] = 28;
		voti[2][1] = 26;
		voti[3][1] = 27;
		voti[4][1] = 21;

		String[] studMigliori = selezionaStudentiMigliori(studenti, voti);
		
		for ( int i = 0 ; i < studMigliori.length; i++ )
			System.out.println("Studente: " + studMigliori[i]);
	}
}