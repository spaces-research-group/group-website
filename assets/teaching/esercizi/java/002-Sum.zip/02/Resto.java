import java.util.Scanner;

public class Resto {
	
	public static void main(String args[]) {
		
		int totaleDaPagare;
		int banconota;
		
		Scanner tastiera = new Scanner(System.in);
		System.out.println("Inserisci il totale da pagare in �");
		totaleDaPagare = tastiera.nextInt();
		System.out.println("Con quale banconota vuoi pagare ?");
		banconota = tastiera.nextInt();
		
		int resto = banconota - totaleDaPagare;
		
		//controlli addizionali opzionali
		while ( resto < 0 ) {
			System.out.println("Hai inserito un importo da pagare errato, riprova");
			totaleDaPagare = tastiera.nextInt();
			resto = banconota - totaleDaPagare;
		}

		while ( resto > 0 ) {
			if ( ( resto / 20 ) >= 1 ) {
				System.out.println("Erogo una banconota da 20�");
				resto -= 20;
			}
			else if ( ( resto / 10 ) >= 1 ) {
				System.out.println("Erogo una banconota da 10�");
				resto -= 10;
			}
			else if ( ( resto / 5 ) >= 1 ) {
				System.out.println("Erogo una banconota da 5�");
				resto -= 5;
			}
			else if ( ( resto / 2 ) >= 1 ) {
				System.out.println("Erogo una moneta da 2�");
				resto -= 2;
			}
			else if ( ( resto / 1 ) >= 1 ) {
				System.out.println("Erogo una moneta da 1�");
				resto -= 1;
			}
		}
		System.out.println("Resto erogato correttamente.");
	}
}
