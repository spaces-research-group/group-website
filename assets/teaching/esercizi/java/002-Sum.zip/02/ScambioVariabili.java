import java.util.Scanner;

public class ScambioVariabili { 
	public static void main (String [] args) {
		System.out.println("Inserisci x e y: ");
		Scanner tastiera = new Scanner(System.in);
		int x = tastiera.nextInt();
		int y = tastiera.nextInt();
		System.out.println ("x = " + x + ", y = " + y);

		if ( x > y ) { 
			// per scambiare i valori e' necessaria una 
			// variabile di appoggio!
			int temp = x; 
			x = y; 
			y = temp;
		} 
		System.out.println ("x = " + x + ", y = " + y); 
	}
}
