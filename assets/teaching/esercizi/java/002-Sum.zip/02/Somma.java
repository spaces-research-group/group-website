public class Somma {
		public static void main(String args[]) {
			int a = 3;
			int b = 4;
			int risultato = a + b;
			System.out.println("La somma vale: " + risultato);
		}
	}
