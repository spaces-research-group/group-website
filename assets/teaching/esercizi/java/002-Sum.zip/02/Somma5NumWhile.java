import java.util.Scanner;

public class Somma5NumWhile{
    public static void main (String[] args) {
        final int N = 5; // valori da sommare
        int count = 1;   // conta i valori letti
        int somma = 0;   // somma dei valori letti
        int num;         // ultimo valore letto
	Scanner tastiera = new Scanner(System.in);


        while (count <= N) {
            System.out.print("Immetti un intero: ");
            num = tastiera.nextInt();
            somma = somma + num;
            count++;
        }        

        System.out.println ("La somma e' " + somma);
    }
}