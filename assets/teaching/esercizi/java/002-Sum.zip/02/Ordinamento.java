import java.util.Scanner;

public class Ordinamento {

	public static void main(String args[]){
		System.out.println("Inserisci 3 numeri");
		Scanner tastiera = new Scanner(System.in);
		int a = tastiera.nextInt();
		int b = tastiera.nextInt();
		int c = tastiera.nextInt();
		int primo, secondo, terzo;
		
		if ( a > b ) {
			primo = a;
			secondo = b;
		}
		else {
			primo = b;
			secondo = a;
		}
		
		if ( c > primo ) {
			terzo = secondo;
			secondo = primo;
			primo = c;
		}
		
		else {
			if ( c < secondo )
				terzo = c;
			else {
				terzo = secondo;
				secondo = c;
			}
		}
			
		System.out.println("I numeri immessi ordinati in ordine decrescente sono : " + primo +", " +  secondo + ", " + terzo);	
		
	}
}
