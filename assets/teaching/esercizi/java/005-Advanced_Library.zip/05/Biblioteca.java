public class Biblioteca 
{
	
	private String[] titoli;
	private boolean[] prestiti;
	private int libriTot;
	private int libriFuori;
	
	public Biblioteca(int maxLibri)
	{
		titoli=new String[maxLibri];
		prestiti=new boolean[maxLibri];
		azzera();
	}
	
	public void azzera()
	{
		libriFuori=0;
		libriTot=0;
	}
    
  	public int cerca(String titolo)
	{
   		for(int i=0;i<libriTot;i++)
			if(titolo.equals(titoli[i])) 
			  return i;
  		return -1;
  	}
    
  	public void aggiungiLibro(String titolo)
	{
   		if(libriTot<titoli.length)
		{
    			titoli[libriTot]=titolo;
			prestiti[libriTot]=false;
    			libriTot++;
		}
 	}
    
 	 public boolean prestaLibro(String titolo)
	{
   		int pos = cerca(titolo);
		if((pos!=-1) && (prestiti[pos]==false))
		{
    	 		prestiti[pos]=true;
    	 		libriFuori++;
    	 		return true;
    		}
    		else return false;    
  	}
    
	public boolean restituisciLibro(String titolo)
	{
		int pos = cerca(titolo);
		if ((pos!=-1) && (prestiti[pos]==true))
		{
			prestiti[pos]=false;
			libriFuori--;
			return true;
		}
		else return false;
	}
	
	public int numLibri()
	{
		return libriTot;
	}
	
	public int numPrestati()
	{
		return libriFuori;
	}
}