public class MainBiblioteca{

	public static void main(String args[]) {

		Biblioteca miaBib = new Biblioteca(50);
		miaBib.aggiungiLibro("Guerra e pace");
		miaBib.aggiungiLibro("Il mondo alla fine del mondo");
		miaBib.aggiungiLibro("Il piacere");
		miaBib.aggiungiLibro("Lolita");
		miaBib.aggiungiLibro("Sulla felicit� e sul dolore");
	
		miaBib.prestaLibro("Lolita");
		miaBib.numLibri();
		miaBib.numPrestati();
		miaBib.restituisciLibro("Lolita");
		miaBib.numPrestati();
	}
}