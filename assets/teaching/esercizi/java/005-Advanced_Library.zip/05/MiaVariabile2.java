public class MiaVariabile2 {

		private static int valore;

		public static int getValore() {
			return valore;
		}
		public static void setValore (int nuovoValore){
			valore = nuovoValore;
		}
	}
