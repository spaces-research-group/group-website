public class Main{

	public static void main(String args[]) {

	MiaVariabile variabile = new MiaVariabile();
	variabile.resetValore();
	System.out.println("la variabile valore ora vale : " + 	variabile.getValore());
	variabile.setValore(8);
	System.out.println("la variabile valore ora vale : " + 	variabile.getValore());
	}
}