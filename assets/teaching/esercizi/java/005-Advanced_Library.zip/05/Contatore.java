public class Contatore {

	private int valore;

	public void incrementa() {
		valore = valore+ 1;
	}

	public void reset() {
		valore = 0;
	}

	public int getValore() {
		return valore;
	}

}