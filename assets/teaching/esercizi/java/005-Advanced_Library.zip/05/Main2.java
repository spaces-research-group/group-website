public class Main2 {
	public static void main(String args[]) {
		int y = 4;
		MiaVariabile2.setValore(3);
		int risultato = MiaVariabile2.getValore() + y;
		System.out.println("La somma vale: "+risultato);
	}
}
