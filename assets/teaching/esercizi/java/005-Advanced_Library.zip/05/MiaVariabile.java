public class MiaVariabile {
	
	private int valore;
	
	public int getValore() {
		return valore;
	}
	
	public void setValore(int newValore) {
		valore = newValore;
	}
	
	public void resetValore() {
		valore = 0;
	}
}
