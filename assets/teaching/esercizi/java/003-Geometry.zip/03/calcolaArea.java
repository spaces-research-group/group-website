public class calcolaArea { 

		public static void calcolaAreaTriangolo() { 
			System.out.println("Area Triangolo: " + ((5.34*3.5)/2));
		}

		public static void calcolaAreaRettangolo() { 
			System.out.println("Area Rettangolo: " + (4.3*2.4));
		}
		public static void calcolaAreaCerchio() { 
			 System.out.println("Area Cerchio: " + (3.14159*2*2));
		}


		public static void main(String[] args) { 
			calcolaAreaTriangolo();
			calcolaAreaRettangolo();
			calcolaAreaCerchio();
		}

}
