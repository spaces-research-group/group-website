public class calcolaAreaParam { 

		public static double calcolaAreaTriangolo(double base, double altezza) { 
			double area = (base*altezza)/2;
			return area; 
		}

		public static double calcolaAreaRettangolo(double base, double altezza) {
			double area = base*altezza;
			return area; 
		}

		public static double calcolaAreaCerchio(double raggio) { 
			double  area = 3.14159*raggio*raggio;
			return area;
		}

		public static void main(String[] args) { 
			double areaT = calcolaAreaTriangolo(10,2);
			System.out.println("Area Triangolo: " + areaT);
			double areaR = calcolaAreaRettangolo(2,4);
			System.out.println("Area Rettangolo: " + areaR);
			double areaC = calcolaAreaCerchio(2);
			System.out.println("Area Cerchio: " + areaC);
		}

}
