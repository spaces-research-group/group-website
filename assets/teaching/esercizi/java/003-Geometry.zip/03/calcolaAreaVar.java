public class calcolaAreaVar { 

		public static double calcolaAreaTriangolo() { 
			double area = (5.34*3.5)/2;
			return area; 
		}

		public static double calcolaAreaRettangolo() {
			double area = 5.34*3.5;
			return area; 
		}

		public static double calcolaAreaCerchio() { 
			double  area = 3.14159*2*2;
			return area;
		}

		public static void main(String[] args) { 
			double areaT = calcolaAreaTriangolo();
			System.out.println("Area Triangolo: " + areaT);
			double areaR = calcolaAreaRettangolo();
			System.out.println("Area Rettangolo: " + areaR);
			double areaC = calcolaAreaCerchio();
			System.out.println("Area Cerchio: " + areaC);
		}

}
