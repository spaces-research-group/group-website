public class calcolaAreaReturn { 

		public static double calcolaAreaTriangolo() { 
			return (5.34*3.5)/2;
		}

		public static double calcolaAreaRettangolo() { 
			return 4.3*2.4;
		}
		public static double calcolaAreaCerchio() { 
			 return 3.14159*2*2;
		}

		public static void main(String[] args) { 
			double areaT = calcolaAreaTriangolo();
			System.out.println("Area Triangolo: " + areaT);
			double areaR = calcolaAreaRettangolo();
			System.out.println("Area Rettangolo: " + areaR);
			double areaC = calcolaAreaCerchio();
			System.out.println("Area Cerchio: " + areaC);
		}

}
