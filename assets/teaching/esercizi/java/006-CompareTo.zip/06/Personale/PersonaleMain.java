public class PersonaleMain {

	public static void main(String[] args) {
		
		Impiegato[] personale = new Impiegato[5];
		
		personale[0] = new Volontario("John Coltrane", "Hamlet, North Carolina", "01234567");
		personale[1] = new Dipendente("Angus Young", "Glasgow, Scotland", "00000666",1600);
		personale[2] = new Giornaliero("Roger Waters", "Great Bookham, Surrey", "555-2783618",450,15);
		personale[3] = new Volontario("Freddie Mercury", "Stone Town, Zanzibar","23781378");
		personale[4] = new Giornaliero("Nino D'Angelo","San Pietro a Patierno, Napoli","0813278937",350,1);
		
		for(Impiegato p:personale){
			System.out.print(p.getNome() + ": ");
			if(p.getPaga()==0.0) 
				System.out.println("Grazie per il vostro contributo!");
			else
				System.out.println(p.getPaga());
		}
	}
	
}
