
public class Giornaliero extends Impiegato{

	double base;
	int giorni;
	
	public Giornaliero(String nome, String indirizzo, String telefono, double base, int giorni) {
		super(nome, indirizzo, telefono);
		this.base = base;
		this.giorni = giorni;
	}

	@Override
	public double getPaga() {
		return giorni*base;
	}

}
