
public interface IImpiegato {
	
	public String getNome();
	public String getIndirizzo();
	public String getTelefono();
	public double getPaga();
}
