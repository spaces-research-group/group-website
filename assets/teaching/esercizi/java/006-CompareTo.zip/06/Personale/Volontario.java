
public class Volontario extends Impiegato{

	public Volontario(String nome, String indirizzo, String telefono) {
		super(nome, indirizzo, telefono);
	}

	@Override
	public double getPaga() {
		return 0.0;
	}

}
