
public abstract class Impiegato implements IImpiegato{

	private String nome;
	private String indirizzo;
	private String telefono;
	
	public Impiegato(String nome, String indirizzo, String telefono){
		this.nome = nome;
		this.indirizzo = indirizzo;
		this.telefono = telefono;
	}
	
	@Override
	public String getNome() {
		return nome;
	}

	@Override
	public String getIndirizzo() {
		return indirizzo;
	}

	@Override
	public String getTelefono() {
		return telefono;
	}

	@Override
	public abstract double getPaga();

}
