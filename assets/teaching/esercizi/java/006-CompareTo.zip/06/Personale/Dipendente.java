
public class Dipendente extends Impiegato {

	
	private double stipendio;
	
	public Dipendente(String nome, String indirizzo, String telefono, double stipendio) {
		super(nome, indirizzo, telefono);
		
		this.stipendio = stipendio;
	}

	
	public double getStipendio() {
		return stipendio;
	}
	
	@Override
	public double getPaga() {
		return stipendio;
	}

}
