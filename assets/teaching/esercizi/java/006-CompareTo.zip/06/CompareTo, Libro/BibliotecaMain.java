import java.util.Scanner;

public class BibliotecaMain {
	public static void main(String args[]) {
		// preparo un array di libri
		Libro2[] biblioteca = new Libro2[10];
		biblioteca[0] = new Libro2("La Divina Commedia", "Dante", 1321);
		biblioteca[1] = new Libro2("Delitto e Castigo", "Dostoevskij", 1999);
		biblioteca[2] = new Libro2("La Gerusalemme Liberata", "Tasso", 214);
		biblioteca[3] = new Libro2("I Demoni", "Dostoevskij", 2000);
		biblioteca[4] = new Libro2("Il Socio", "Grisham", 2000);
		biblioteca[5] = new Libro2("Le Cronache di Narnia", "Lewis", 2001);
		biblioteca[6] = new Libro2("Il Signore degli Anelli", "Tolkien", 1999);
		biblioteca[7] = new Libro2("Lo Hobbit", "Tolkien", 2010);
		biblioteca[8] = new Libro2("La Divina Commedia", "Dante", 2013);
		biblioteca[9] = new Libro2("Lo Hobbit", "Tolkien", 2010);
	
		System.out.println("" + biblioteca[0].compareTo(biblioteca[8]));
		System.out.println("" + biblioteca[7].compareTo(biblioteca[9]));
		System.out.println("" + biblioteca[0].compareTo(biblioteca[1]));
	}
}
