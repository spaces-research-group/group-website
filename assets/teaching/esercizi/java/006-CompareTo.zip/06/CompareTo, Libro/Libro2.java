public class Libro2 extends Libro implements Comparable<Libro2>{
	
	private int annoProduzione;
	
	public Libro2(String titolo, String autore, int anno) {
		super(titolo, autore);
		annoProduzione = anno;
	}
	
	public int getAnnoProduzione() { 
		return annoProduzione; 
	}
	
	public void setAnnoProduzione(int anno) { 
		this.annoProduzione = anno; 
	}

	@Override
	public int compareTo(Libro2 l) {
		if (this.titolo.equals(l.getTitolo())) {
			if (this.annoProduzione < l.getAnnoProduzione())
				return -1;
			else if (this.annoProduzione > l.getAnnoProduzione())
				return 1;
			else
				return 0;
		}
		else return this.titolo.compareTo(l.getTitolo()); 
		//utilizzo la compareTo della classe String
	}

}