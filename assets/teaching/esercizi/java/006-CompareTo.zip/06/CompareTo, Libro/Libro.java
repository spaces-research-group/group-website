public class Libro {
	
	String autore;
	String titolo;
	
	// costruttore
	public Libro(String titolo, String autore) {
		this.autore = autore;
		this.titolo = titolo;
	}
	
	//metodi di set
	public void setAutore(String autore) {
		this.autore = autore;
	}
	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}
	
	// metodi di accesso
	public String getAutore() { return autore; }
	public String getTitolo() { return titolo; }
	
	// metodo "equals"
	public boolean equals(Libro l) {
		if (l == null) return false;
		else return titolo.equals(l.titolo);
	}
	
	// metodo "toString"
	public String toString() {
		return "\"" + titolo + "\", di " + autore;
	}
	
	public static int conta(Libro l, Libro[] bib) {
		int count = 0;
		for(int i = 0; i < bib.length; i++)
			if (l.equals(bib[i]))
				count++;
		return count;
	}
}