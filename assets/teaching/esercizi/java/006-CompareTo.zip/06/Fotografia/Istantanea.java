import java.util.Date;

public class Istantanea extends Analogica{

	String modelloPellicola;
	public Istantanea(String marca, String modello, Date dataAcquisto, double prezzo, String modelloPellicola) {
		super(marca, modello, dataAcquisto, prezzo);
		this.modelloPellicola = modelloPellicola;
	}

	public String getmodelloPellicola() {
		return modelloPellicola;
	}
	
	public String toString(){
		return super.toString() + ", pellicola : " + getmodelloPellicola();
	}
}
