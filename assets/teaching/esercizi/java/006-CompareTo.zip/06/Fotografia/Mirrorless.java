import java.util.Date;

public class Mirrorless extends Digitale{
	
	private boolean mirinoElettronico; //true se mirino elettronico presente, false altrimenti

	public Mirrorless(String marca, String modello, Date dataAcquisto, double prezzo, double risoluzione,
			int sensibilitaIso, boolean mirinoElettronico) {
		super(marca, modello, dataAcquisto, prezzo, risoluzione, sensibilitaIso);
		this.mirinoElettronico = mirinoElettronico;
		// TODO Auto-generated constructor stub
	}
	
	public boolean haMirinoElettronico(){
		if ( mirinoElettronico)
			return true;
		return false;
	}
	
	public String toString(){
		return super.toString() + ", mirino elettronico : " + haMirinoElettronico();
	}

}
