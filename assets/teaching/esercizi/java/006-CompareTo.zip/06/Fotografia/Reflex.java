import java.util.Date;


public class Reflex extends Digitale{
	
	String modelloSpecchio;

	public Reflex(String marca, String modello, Date dataAcquisto, double prezzo, double risoluzione,
			int sensibilitaIso, String modelloSpecchio) {
		super(marca, modello, dataAcquisto, prezzo, risoluzione, sensibilitaIso);
		this.modelloSpecchio = modelloSpecchio;
	}
	
	public String getModelloSpecchio(){
		return modelloSpecchio;
	}
	
	public String toString(){
		return super.toString() + ", modello specchio : " + getModelloSpecchio();
	}

}
