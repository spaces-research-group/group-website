import java.util.Date;

public interface IMacchinaFotografica {
	
	public String getMarca();
	public String getModello();
	public double getPrezzo();
	public boolean controllaGaranzia(Date oggi);

}
