import java.util.Date;


public class Rullino extends Analogica{
	
	private int sensibilitaAsa;
	
	public Rullino(String marca, String modello, Date dataAcquisto, double prezzo, int sensibilitaAsa) {
		super(marca, modello, dataAcquisto, prezzo);
		this.sensibilitaAsa = sensibilitaAsa;
	}

	public int getSensibilitaAsa() {
		return sensibilitaAsa;
	}
	
	public String toString(){
		return super.toString() + ", ASA : " + getSensibilitaAsa();
	}
}
