import java.util.Date;

public class MainFotografia {
	
	public static void main(String[] args){
	
	MacchinaFotografica reflex = new Reflex("Canon","5DMark3", new Date(2012, 05, 13), 2985 ,22.3, 128000, "Pentaprisma");
	MacchinaFotografica rullino = new Rullino("Holga", "120N", new Date(1999, 07, 22), 66, 1600);
	Digitale mirrorless = new Mirrorless("Nikon", "1V1", new Date(2012, 9, 01), 499, 10.1, 3200, true);
	Analogica istantanea = new Istantanea("Polaroid", "Supercolor600", new Date(1993, 12, 10), 94, "Serie 600");
	
	MacchinaFotografica[] macchine = new MacchinaFotografica[4];
	macchine[0] = reflex;
	macchine[1] = mirrorless;
	macchine[2] = rullino;
	macchine[3] = istantanea;
	
	mirrorless.estendiGaranzia(); //vediamo che la Nikon 1V1 che aveva un prezzo di 499, ora avr� un prezzo di 699.
								  //Questo sovrapprezzo � dovuto al pagamento di 200 euro per l'estensione di garanzia
	for ( int i = 0 ; i < macchine.length ; i++){
		System.out.println(macchine[i].toString());
		}
	}
}
