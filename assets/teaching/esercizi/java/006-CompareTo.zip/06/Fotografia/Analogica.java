import java.util.Date;

public abstract class Analogica extends MacchinaFotografica{
	
	public static final int GaranziaAnalogica = 4;

	public Analogica(String marca, String modello, Date dataAcquisto, double prezzo) {
		super(marca, modello, dataAcquisto, prezzo);		
	}
	
	public boolean controllaGaranzia(Date oggi){
		if ( oggi.getYear()-getDataAcquisto().getYear() < GaranziaAnalogica ) //in garanzia
			return true;
		else 
			if ( oggi.getYear()-getDataAcquisto().getYear() > GaranziaAnalogica) //fuori garanzia
				return false;
			else if (oggi.getMonth()-getDataAcquisto().getMonth() < 0 ) //nell'ultimo anno di garanzia
				return true;
			else 
				return false;
	}

}
