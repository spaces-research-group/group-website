import java.util.Date;

public abstract class Digitale extends MacchinaFotografica{
	
	public static final int GaranziaDigitale = 2;
	
	private double risoluzione;
	private int sensibilitaIso;
	private boolean garanziaEstesa = false;
	
	public Digitale(String marca, String modello, Date dataAcquisto, double prezzo, double risoluzione, int sensibilitaIso) {
		super(marca, modello, dataAcquisto, prezzo);
		this.sensibilitaIso = sensibilitaIso;
		this.risoluzione = risoluzione;
		
	}

	public double getRisoluzione() {
		return risoluzione;
	}
	
	public int getSensibilitaIso() {
		return sensibilitaIso;
	}
	
	@Override
	public boolean controllaGaranzia(Date oggi) {
		if ( oggi.getYear()-getDataAcquisto().getYear() < GaranziaDigitale ) //in garanzia
			return true;
		else 
			if ( oggi.getYear()-getDataAcquisto().getYear() > GaranziaDigitale) //fuori garanzia
				return false;
			else if (oggi.getMonth()-getDataAcquisto().getMonth() < 0 ) //nell'ultimo anno di garanzia
				return true;
			else 
				return false;
	}
	
	public void estendiGaranzia(){
		garanziaEstesa = true;
		prezzo += 200.00; //modifico la variabile prezzo della classe base
	}
	
	public String toString(){
		return super.toString() +", " + getRisoluzione() + " Mpx, ISO : " + getSensibilitaIso();  
	}
}
