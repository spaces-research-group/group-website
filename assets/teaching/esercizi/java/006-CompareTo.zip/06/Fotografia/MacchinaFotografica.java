import java.util.Date;

public abstract class MacchinaFotografica implements IMacchinaFotografica{

	private String marca;
	private String modello;
	protected double prezzo;
	private Date dataAcquisto;
	
	public MacchinaFotografica(String marca, String modello, Date dataAcquisto, double prezzo)
	{
		this.marca = marca;
		this.modello = modello;
		this.dataAcquisto = dataAcquisto;
		this.prezzo = prezzo;
	}
	
	public String getMarca() {
		return marca;
	}
	
	public String getModello() {
		return modello;
	}
	
	public double getPrezzo() {
		return prezzo;
	}
	
	public Date getDataAcquisto(){
		return dataAcquisto;
	}
	
	public String toString(){
		return "" + getMarca() + " " + getModello() + ", � " + getPrezzo();
	}
	
	public abstract boolean controllaGaranzia(Date oggi);
	
}
