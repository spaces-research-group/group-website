public class Oggetto implements Comparable<Oggetto> {
	
	private String tipo;
	private	int anno;
	private	String stato;
	
	public Oggetto(String tipo,int anno, String stato)	{
		this.tipo = tipo;
		this.anno = anno;
		this.stato = stato;
	}

	public String getTipo() {
		return tipo;
	}

	public int getAnno() {
		return anno;
	}

	public String getStato() {
		return stato;
	}
	
	public String toString() {
		return tipo + " del " +	anno + " in " +	" stato	di conservazione " + stato;
	}

	public boolean equals(Object o) {
		return equals((Oggetto)	o);
	}
	
	public boolean equals(Oggetto o) {
		return tipo.equals(o.tipo) && anno == o.anno;
	}
	@Override
	public int compareTo(Oggetto o) {
		int res	= tipo.compareTo(o.tipo);
		if (res != 0)
			return res;
		else
			return o.anno - anno;
	}
}
