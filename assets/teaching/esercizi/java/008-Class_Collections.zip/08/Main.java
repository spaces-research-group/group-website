import java.util.*;

public class Main {
	public static void main(String[] args) {
		
		//punto 1
		Set<Negozio> negozi = new TreeSet<>();
		Negozio sedeDiRoma = new Negozio("Roma");
		Negozio sedeDiBologna = new Negozio("Bologna");
		Negozio sedeDiMilano = new Negozio("Milano");
		negozi.add(sedeDiRoma); negozi.add(sedeDiBologna); negozi.add(sedeDiMilano);
		
		//punto 2
		Scanner tastiera = new Scanner(System.in);
		System.out.println("Inserire la citt� ..");
		String citta = tastiera.nextLine();
		Negozio negozio = new Negozio(citta);
		
		//punto 3
		while (!negozi.add(negozio)) {
			System.out.println("Negozio	gia' presente, inserire una citta'differente ..");
			negozio.setCitta(tastiera.nextLine());
		}
		System.out.println("Aggiunta sede di " + citta);
		
		//punto 4
		Oggetto o1 = new Oggetto("vaso", 1992, "pessimo");
		sedeDiRoma.aggiungi(o1);
		Oggetto o2 = new Oggetto("sedia", 2000, "ottimo");
		sedeDiBologna.aggiungi(o2);
		Oggetto o3 = new Oggetto("abat-jour", 1981, "buono");
		sedeDiBologna.aggiungi(o3);
		Oggetto o4 = new Oggetto("abat-jour", 1987, "buono");
		sedeDiMilano.aggiungi(o3);
		sedeDiMilano.aggiungi(o4);
		negozio.aggiungi(new Oggetto("sedia", 1992, "discreto"));
		negozio.aggiungi(new Oggetto("abat-jour", 1989, "pessimo"));
		negozio.aggiungi(new Oggetto("Giradischi", 1977, "discreto"));
		negozio.aggiungi(new Oggetto("tavolo", 1989, "pessimo"));
		negozio.aggiungi(new Oggetto("lampadario", 1993, "ottimo"));		
		
		//punto 5
		System.out.print("Inserisci il tipo dell'oggetto da cercare: ");
		String a = tastiera.nextLine();
		List<Oggetto> inv = null;
		for	( Negozio neg :	negozi)	{
			inv = neg.cerca(a);
			if (inv.isEmpty())
				System.out.println("Nella sede di " + neg.getCitta() + " non � stata trovata nessuna corrispondenza");
			else {
				System.out.println("Nella sede di " + neg.getCitta() + " e'stata trovata la seguente corrispondenza :");
				System.out.println("->" + inv.toString() + "<-");
			}
		}
	}
}
