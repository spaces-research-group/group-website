import java.util.*;

public class Negozio implements Comparable<Negozio> {
	
	private String citta;
	private List<Oggetto> inventario;
	
	public Negozio(String citta){
		this.citta = citta;
		inventario = new ArrayList<Oggetto>();
	}

	public String getCitta() {
		return citta;
	}
	
	public void setCitta(String citta) {
		this.citta = citta;
	}
	
	public void aggiungi (Oggetto o ) {
		int i = 0;
		while( i < inventario.size() && inventario.get(i).compareTo(o) < 0)
			i++;
		inventario.add(i, o);
	}
	
	public List<Oggetto> cerca(String tipo) {
		List<Oggetto> trovati = new ArrayList<Oggetto>();
			for (Oggetto o : inventario )
				if (o.getTipo().equalsIgnoreCase(tipo))
					trovati.add(o);
		return trovati;
	}

	@Override
	public int compareTo(Negozio n) {
		return citta.compareTo(n.getCitta());
	}
}
