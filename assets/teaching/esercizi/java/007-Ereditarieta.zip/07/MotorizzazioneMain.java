import java.util.*;

public class MotorizzazioneMain {
	public static void main(String args[]) {
		// costruisco un nuova istanza della classe "Motorizzazione"
		Motorizzazione m = new Motorizzazione("Bologna");

		// aggiungo le informazioni sugli automezzi
		m.aggiungi(new Automobile("Seat Ibiza", "DS 244 TC", 2009));
		m.aggiungi(new Automobile("Volkswagen Polo", "CZ 123 QR", 2006));
		m.aggiungi(new Automobile("Volkswagen Passat", "DZ 221 CC", 2010));
		m.aggiungi(new Automobile("Fiat Punto", "EH 002 AB", 2011));
		m.aggiungi(new Automobile("Toyota Prius", "EL 342 HH", 2012));
				
		// provo ad aggiungere un mezzo duplicato
		Automobile a = new Automobile("Fiat Punto", "DS 244 TC", 2008);
		System.out.println("Provo ad aggiungere: " + a);
		if (!m.aggiungi(a))
			System.out.println("L'auto ha la stessa targa di una gia' registrata");
			
		// stampo il numero di auto registrate
		System.out.println("Numero di auto registrate: " + m.quante());
	}
}