public class Contatore implements Comparable<Contatore>{

	private int valore;

	public void inc() {
		valore = valore+ 1;
	}

	public void reset() {
		valore = 0;
	}

	public int getValore() {
		return valore;
	}

	@Override
	public int compareTo(Contatore o) {
		return this.valore-o.getValore();
	}
	
	public String toString(){
		return "" + valore;
	}

}