import java.util.*;

public class Motorizzazione {
	private String citta;
	private Set<Automobile> mezzi;
	
	public Motorizzazione(String citta) {
		this.citta = citta;
		mezzi = new TreeSet<Automobile>();
	}
	
	public String getCitta() { return citta; }
	
	public String toString() { return "motorizzazione di " + citta; }
	
	public boolean equals(Motorizzazione m) { return citta.equals(m.citta); }
	public boolean equals(Object o) { return equals((Motorizzazione) o); }
	
	public boolean aggiungi(Automobile a) { return mezzi.add(a); }
	
	public int quante() { return mezzi.size(); }
	
	public int quanteDaRevisionare(int annocorrente) {
		int n = 0;
		for (Automobile a : mezzi)
			if (a.getAnno() < annocorrente-1) n++;
		return n;
	}
}