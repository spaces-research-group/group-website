import java.util.*;

public class AutomobileMain {
	public static void main(String args[]) {
		Set<Automobile> mezzi = new TreeSet<Automobile>();
		mezzi.add(new Automobile("Seat Ibiza", "DS 244 TC", 2009));
		mezzi.add(new Automobile("Volkswagen Polo", "CZ 123 QR", 2006));
		mezzi.add(new Automobile("Volkswagen Passat", "DZ 221 CC", 2010));
		mezzi.add(new Automobile("Fiat Punto", "EH 002 AB", 2011));
		mezzi.add(new Automobile("Toyota Prius", "EL 342 HH", 2012));
		mezzi.add(new Automobile("Volkswagen Passat", "DZ 221 CC", 2010));
		
		for (Automobile a : mezzi)
			System.out.println(a.toString());
		
		//di particolare importanza notare l'ordine in cui vengono stampate le auto, seguono la compareTo sulla targa
		//notare anche che l'automobile VolksWagen Passat � stata inserita 2 volte nel TreeSet ma la seconda volta
		//non � stata aggiunta perch� era gi� presente. La add ha restituito "false"
	}
}