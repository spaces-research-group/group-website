import java.util.*;

public class TreeSetArrayList {
	public static void main(String[] args) {
		Contatore c1 = new Contatore();
			c1.inc();
			c1.inc(); // il contatore c1 vale 2
		Contatore c2 = new Contatore();
			c2.inc(); // il contatore c2 vale 1
		Contatore c3 = new Contatore();
			c3.inc();
			c3.inc();
			c3.inc(); // il contatore c3 vale 3
		Contatore c4 = new Contatore();
			c4.inc(); //il contatore c4 vale 1
			
		List<Contatore> contatoriList = new ArrayList<Contatore>();
			contatoriList.add(c1);
			contatoriList.add(c2);
			contatoriList.add(0, c3);
			contatoriList.add(c4);
		System.out.println("Stampo contatori contenuti nell'ArrayList :");
		for	(Contatore c: contatoriList)
			System.out.println(c);
		
	
		Set<Contatore> contatoriSet = new TreeSet<Contatore>();
			contatoriSet.add(c1);
			contatoriSet.add(c2);
			contatoriSet.add(c3);
			contatoriSet.add(c4);
		System.out.println("Stampo contatori contenuti nel Treeset :");
		for	(Contatore c: contatoriSet)
			System.out.println(c);
		//c4 non viene inserito perch� di valore uguale a c2 precedentemente inserito.
		//c'� ordinamento automatico
	}
}
	