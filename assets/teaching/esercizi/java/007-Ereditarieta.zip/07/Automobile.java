public class Automobile implements Comparable<Automobile> {
	
	private String modello;
	private String targa;
	private int anno;
	
	public Automobile(String modello, String targa, int anno) {
		this.modello = modello;
		this.targa = targa;
		this.anno = anno;
	}
	
	public String getModello() { 
		return modello;
	}
	
	public String getTarga() { 
		return targa; 
	}
	
	public int getAnno() { 
		return anno;
	}
	
	public String toString() {
		return modello + " - " + targa + " (" + anno + ")";
	}
	
	public boolean equals(Automobile a) {
		return targa.equals(a.targa);
	}
	
	public int compareTo(Automobile a) {
		return targa.compareTo(a.targa);
	}
}